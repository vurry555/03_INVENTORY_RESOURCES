extends Node2D

@export var item_resources: ItemData

var _busy := false


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player" and not _busy:
		# Дерево срубается только топором
		if body.equipped_tool and body.equipped_tool.name == "axe":
			_busy = true
			spawn_wood()
			queue_free()


func spawn_wood() -> void:
	Global.add_item(item_resources)
