extends Node2D

@export var item_resources: ItemData
@export var sprite: Sprite2D

var _busy := false

func _ready() -> void:
	sprite.texture = item_resources.icon



# Если в Area2D находится любое body, вызывается данная функция
func _on_area_2d_body_entered(body: Node2D) -> void:
	# Проверка body = Player
	if body.name == "Player" and not _busy:
		_busy = true
		# Вызов add_item с ресурсом ItemData. Удаляем предмет, только если он взят
		if Global.add_item(item_resources):
			queue_free()
		_busy = false
