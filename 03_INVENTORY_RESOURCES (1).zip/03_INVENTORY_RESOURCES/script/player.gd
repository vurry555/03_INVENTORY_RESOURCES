extends CharacterBody2D

var speed = 40
var is_sitting = false
# Текущий инструмент в руке (null, если в руке не инструмент)
var equipped_tool: ItemData

@export var anim: AnimatedSprite2D
@export var name_label: Label
@export var hand: Sprite2D
@export var item_resources: ItemData # Сюда закинут топор, это будет 1 предмет
@export var item_world_scene: PackedScene # Сцена выброшенного предмета (item.tscn)


func _ready() -> void:
	name_label.text = Global.player_name
	anim.play("idle")
	Global.inventory_updated.connect(update_hand_visual)
	# Топор выдаем один раз за игру
	if not Global.axe_given:
		Global.axe_given = true
		Global.add_item(item_resources)
	update_hand_visual()
	update_hand_side()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact"):
		if is_sitting:
			is_sitting = false
			anim.play("idle")
		else:
			is_sitting = true
			anim.play("sit")

	if event.is_action_pressed("next_item"):
		change_selection(1)
	if event.is_action_pressed("prev_item"):
		change_selection(-1)
	if event.is_action_pressed("drop_item"):
		drop_item()


func _physics_process(_delta: float) -> void:
	# Отмена расчета движения и ввода, если игрок сидит
	if is_sitting:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var input = Vector2(
		Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"),
		Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	)
	velocity = input.normalized() * speed
	move_and_slide()

	# Разворот спрайта в зависимости от направления персонажа
	if input.x > 0:
		anim.flip_h = true
		update_hand_side()
	elif input.x < 0:
		anim.flip_h = false
		update_hand_side()

	# Переключение состояний анимации
	if input != Vector2.ZERO:
		anim.play("walk")
	else:
		anim.play("idle")


# Предмет в руке держим с той стороны, куда смотрит игрок
func update_hand_side() -> void:
	hand.flip_h = anim.flip_h
	hand.position.x = 6 if anim.flip_h else -6


func change_selection(direction: int) -> void:
	if Global.inventory.size() == 0:
		return

	# Алгоритм зацикливания индекса
	Global.active_slot_index = (Global.active_slot_index + direction) % Global.inventory.size()
	if Global.active_slot_index < 0:
		Global.active_slot_index = Global.inventory.size() - 1

	update_hand_visual()
	Global.selection_changed.emit()


func update_hand_visual() -> void:
	if Global.inventory.size() == 0:
		hand.texture = null
		equipped_tool = null
		return

	var item = Global.inventory[Global.active_slot_index]
	if item:
		hand.texture = item.icon
		equipped_tool = item if item.is_tool else null
	else:
		hand.texture = null
		equipped_tool = null


func drop_item() -> void:
	if Global.inventory.size() > 0:
		var item_to_drop = Global.inventory[Global.active_slot_index]
		# Убираем из инвентаря (UI и рука обновятся по сигналу inventory_updated)
		Global.remove_one(Global.active_slot_index)

		# Спавним предмет в мире
		spawn_dropped_item(item_to_drop)

		Global.selection_changed.emit()


func spawn_dropped_item(item_to_drop: ItemData) -> void:
	var new_item = item_world_scene.instantiate()
	new_item.item_resources = item_to_drop

	# Бросаем рядом, но не под ноги, чтобы предмет не подобрался сразу же
	var random_offset = Vector2.from_angle(randf() * TAU) * randf_range(18, 26)
	new_item.position = self.position + random_offset

	get_tree().current_scene.add_child(new_item)
