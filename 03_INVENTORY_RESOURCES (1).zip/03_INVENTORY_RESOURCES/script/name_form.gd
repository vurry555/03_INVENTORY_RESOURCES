extends Control

@export var name_edit: LineEdit
@export var error_label: Label
# Сцена, которая запускается после формы
@export var next_scene: PackedScene


func _ready() -> void:
	name_edit.grab_focus()


func _on_start_button_pressed() -> void:
	_try_start()


func _on_name_edit_text_submitted(_text: String) -> void:
	_try_start()


func _try_start() -> void:
	var player_name = name_edit.text.strip_edges()
	# Имя проверяется на количество символов (больше 2)
	if player_name.length() <= 2:
		error_label.text = "Минимум 3 символа!"
		return

	# Игроку присваивается это имя
	Global.player_name = player_name

	var new_scene = next_scene.instantiate()
	get_tree().root.add_child(new_scene)
	get_tree().current_scene.queue_free()
	get_tree().current_scene = new_scene
