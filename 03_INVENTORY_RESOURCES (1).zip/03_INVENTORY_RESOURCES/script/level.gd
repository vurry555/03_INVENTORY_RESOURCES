extends Node2D

# Размер карты в пикселях (нужен, чтобы камера не выходила за края)
@export var map_size: Vector2i = Vector2i(384, 256)

@onready var camera: Camera2D = $Player/Camera2D


func _ready() -> void:
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = map_size.x
	camera.limit_bottom = map_size.y
