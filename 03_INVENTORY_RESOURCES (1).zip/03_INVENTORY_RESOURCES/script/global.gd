extends Node

# Сигнал уведомления об обновлении инвентаря (старый сигнал item_collected удален)
signal inventory_updated
# Сигнал о смене выбранного слота (подписан UI)
signal selection_changed

# Ограничение инвентаря (задание 13)
@export var max_inventory_size: int = 10

var player_name: String = "Player"
var inventory: Array[ItemData] = []
var active_slot_index: int = 0
# Чтобы топор выдавался только один раз за игру, а не при каждой смене сцены
var axe_given: bool = false


# Добавляем предмет в инвентарь. Возвращает true, если предмет взят.
func add_item(item: ItemData) -> bool:
	if inventory.has(item):
		# Стакинг (задание 12): такой предмет уже есть, увеличиваем счетчик
		item.amount += 1
	else:
		# Ограничение (задание 13): инвентарь полон, предмет не подбирается
		if inventory.size() >= max_inventory_size:
			return false
		item.amount = 1
		inventory.append(item)
	# Оповещаем UI об изменениях
	inventory_updated.emit()
	return true


# Убираем из слота один предмет (если в стопке больше одного, уменьшаем счетчик)
func remove_one(index: int) -> void:
	var item = inventory[index]
	item.amount -= 1
	if item.amount <= 0:
		inventory.remove_at(index)
	# Корректируем индекс выбранного слота
	active_slot_index = clampi(active_slot_index, 0, maxi(inventory.size() - 1, 0))
	inventory_updated.emit()
