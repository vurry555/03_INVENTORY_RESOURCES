extends Area2D

# Путь к сцене, в которую ведет портал
@export_file("*.tscn") var target_scene: String

var _used := false


func _on_body_entered(body: Node2D) -> void:
	if _used or body.name != "Player":
		return
	_used = true
	# Меняем сцену не сразу, а после обработки физики
	call_deferred("_change_scene")


func _change_scene() -> void:
	var tree = get_tree()
	var old_scene = tree.current_scene
	var new_scene = load(target_scene).instantiate()
	tree.root.add_child(new_scene)
	tree.current_scene = new_scene
	old_scene.queue_free()
