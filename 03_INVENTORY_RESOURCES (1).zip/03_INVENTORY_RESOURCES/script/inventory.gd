extends CanvasLayer

@export var grid: GridContainer


func _ready() -> void:
	Global.inventory_updated.connect(refresh_ui)
	Global.selection_changed.connect(update_selection_visual)
	refresh_ui()


func refresh_ui() -> void:
	# Очистка старых слотов
	for child in grid.get_children():
		grid.remove_child(child)
		child.queue_free()

	# Создание новых на основе данных из Global
	for item in Global.inventory:
		var slot = Button.new()
		slot.icon = item.icon
		# Иконка по центру, а если есть счетчик - слева от него
		slot.icon_alignment = HORIZONTAL_ALIGNMENT_LEFT if item.amount > 1 else HORIZONTAL_ALIGNMENT_CENTER
		slot.custom_minimum_size = Vector2(36, 22)
		# Если предметов в стопке больше одного, показываем их количество
		slot.text = str(item.amount) if item.amount > 1 else ""
		# Слоты нужны только для показа: клики и навигация клавишами им не нужны
		slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.focus_neighbor_left = NodePath(".")
		slot.focus_neighbor_right = NodePath(".")
		slot.focus_neighbor_top = NodePath(".")
		slot.focus_neighbor_bottom = NodePath(".")
		slot.focus_next = NodePath(".")
		slot.focus_previous = NodePath(".")
		grid.add_child(slot)

	update_selection_visual()


# Выбранный слот подсвечивается рамкой focus
func update_selection_visual() -> void:
	var slots = grid.get_children()
	for i in range(slots.size()):
		if i == Global.active_slot_index:
			slots[i].grab_focus()
		else:
			slots[i].release_focus()
